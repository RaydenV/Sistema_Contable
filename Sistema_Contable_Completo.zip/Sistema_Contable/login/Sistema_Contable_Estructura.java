
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

public class Sistema_Contable_Estructura {

   public static void main(String[] args) {
      // TODO Auto-generated method stub
     
      String usuarioCorrecto = "Bryant";
      String contraseñaCorrecta = "Velasquez";
      int intentos = 0;

      while (intentos < 3) {
         String usuario = JOptionPane.showInputDialog(null, "Usuario", "Usuario", 3);
         JPasswordField passwordField = new JPasswordField();
         int respuestaContraseña = JOptionPane.showConfirmDialog(null, passwordField, "Contraseña:",
               JOptionPane.OK_CANCEL_OPTION, 3);
         if (respuestaContraseña != JOptionPane.OK_OPTION) {
            return;
         }
         String contraseña = new String(passwordField.getPassword());
         if (usuarioCorrecto.equalsIgnoreCase(usuario) && contraseñaCorrecta.equalsIgnoreCase(contraseña)) {
            JOptionPane.showMessageDialog(null, "Inicio de sesion exitoso");
            interfaz();
            return;

         } else {
            JOptionPane.showMessageDialog(null, "usuario o contraseña incorrectos.");
            intentos++;
         }
         if (intentos == 3) {
            JOptionPane.showMessageDialog(null, "usuario bloqueado.Porfavor, contactese con un administrador.");
            return;

         }
      }
   }

   public static void interfaz() {
      String[] opciones = { "Balance General", "Estado de Resultados", "Estado de Flujo" };
      int seleccion = JOptionPane.showOptionDialog(null, "Seleccione un informe:", "Opciones",
            JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, opciones, opciones[0]);

      if (seleccion == 0) {
         balance_general();
         interfaz();
      }
      if (seleccion == 1) {
    	estado_de_resultado();
    	interfaz();
      }
      if (seleccion == 2) {
    	  estado_de_flujo();
    	  interfaz(); 
      }
   }

   public static void balance_general() {
      double[] activosCirculantes = { 10000.00, 2409980.00, 892100.00, 10000.00 };
      double totalActivosCirculantes = 3322080.00;
      String[] nombresActivosCirculantes = { "Caja", "Bancos", "Inventario", "Cuentas por Cobrar" };
      double[] activosFijos = { 125000.00, 250700.00 };
      double totalActivosFijos = 375700.00;
      String[] nombresActivosFijos = { "Terrenos", "Maquinaria" };
      double totalActivos = 3697780.00;
      double[] pasivosCirculantes = { 85500.00, 7500.00 };
      double totalPasivoCirculante = 93000.00;
      String[] nombresPasivosCirculantes = { "Cuentas por Pagar", "Documentos por Pagar" };
      double prestamoLP = 20000.00;
      double totalPasivos = 113000.00;
      double patrimonio = 3487950.00;
      double utilidadNeta = 96830.00;
      double totalCapitalContable = 3584780.00;
      double totalPasivosMasCapitalContable = 3697780.00;
      System.out.println("Balance General");
      System.out.println("--------------------------------------------------");
      System.out.println("Activos Circulantes");
      for (int i = 0; i < activosCirculantes.length; i++) {
         System.out.println(nombresActivosCirculantes[i] + ": $" + activosCirculantes[i]);
      }
      System.out.println("Total Activos Circulantes: $" + totalActivosCirculantes);
      System.out.println("--------------------------------------------------");
      System.out.println("Activos Fijos");
      for (int i = 0; i < activosFijos.length; i++) {
         System.out.println(nombresActivosFijos[i] + ": $" + activosFijos[i]);
      }
      System.out.println("Total Activos Fijos: $" + totalActivosFijos);
      System.out.println("--------------------------------------------------");
      System.out.println("Total Activos: $" + totalActivos);
      System.out.println("--------------------------------------------------");
      System.out.println("Pasivos Circulantes");
      for (int i = 0; i < pasivosCirculantes.length; i++) {
         System.out.println(nombresPasivosCirculantes[i] + ": $" + pasivosCirculantes[i]);
      }
      System.out.println("Total Pasivo Circulante: $" + totalPasivoCirculante);
      System.out.println("--------------------------------------------------");
      System.out.println("No Circulantes");
      System.out.println("Préstamo LP: $" + prestamoLP);
      System.out.println("Total Pasivos: $" + totalPasivos);
      System.out.println("--------------------------------------------------");
      System.out.println("Capital Contable");
      System.out.println("Patrimonio: $" + patrimonio);
      System.out.println("Utilidad Neta: $" + utilidadNeta);
      System.out.println("Total Capital Contable: $" + totalCapitalContable);
      System.out.println("--------------------------------------------------");
      System.out.println("Total Pasivos + CapitalContable:$" + totalPasivosMasCapitalContable);
      }      
      
      public static void estado_de_resultado() {
    	  
    	  double[]ventas = {600000.00};
    		double[]costoVenta= {385000.00};
    	    double[]utilidadBruta=new double[1];
    	    double[]gastoVenta={84482.00};
    	    double[]gastoAdministracion={33688.00};
    	    double[]totalGastosOperaciones=new double[1];
    	    double[] utilidadEjercicio = new double[1];

    	    
    	    utilidadBruta[0] = ventas[0]-costoVenta[0];
    	    totalGastosOperaciones[0]=gastoVenta[0]+ gastoAdministracion[0]; 
    	    utilidadEjercicio[0] = utilidadBruta[0] - totalGastosOperaciones[0];


    	    
    	    System.out.println("Estado de Resultados");
    	    System.out.println("====================");
    	    System.out.println("Ventas:$ + ventas[0]");
    	    System.out.println("Costo de Venta:$" + costoVenta[0]);
    	    System.out.println("Utilidad Bruta: $" + utilidadBruta[0]);
    	    System.out.println("Gasto de Venta:$" + gastoVenta[0]);
    	    System.out.println("Gasto de Administracion:$"  + gastoAdministracion[0]);
    	    System.out.println("Total Gastos de Operaciones:$" + totalGastosOperaciones[0]);
    	    System.out.println("Utilidad del Ejercicio:$" + utilidadEjercicio[0]);	  
      }
      public static void estado_de_flujo() {
    	  double efectivoRecibidoVentas=500000.00;
    	  double abonoCuentasCobrarClientes = 90000.00;
    	  double depositosCajaBancos = 0.00; 
    	  // No se proporcionó el valor, debes ingresarlo
    	  double compraInventario = 380000.00;
    	  double pagoRentaLocal = 40470.00;
    	  double pagoServiciosBasicos = 25000.00;
    	  double pagoGastosCompras = 52700.00;
    	  double abonoProveedores = 29500.00;
    	  double subtotal1 = 590000.00;
    	  double subtotal2 = 527670.00;
    	  double flujoEfectivoOperacion = 62330.00;
    	  double saldoFinalEjercicio = 62330.00;
    	  double saldoCajaBancos = 2357650.00;
    	  double efectivoEquivalente = 2419980.00;
    	  double resultadoCuentaCaja = 10000.00;
    	  double resultadoCuentaBancos = 2409980.00;
    	  double totalComprobable = 2419980.00;

    	  System.out.println("Estado de Flujo de Efectivo");
    	  System.out.println("----------------------------");
    	  System.out.println("Efectivo recibido por Venta de Productos: $" + efectivoRecibidoVentas);
    	  System.out.println("Abono a Cuentas por Cobrar Clientes: $" + abonoCuentasCobrarClientes);
    	  System.out.println("Menos:");
    	  System.out.println("Depósitos de Caja a Bancos: $" + depositosCajaBancos);
    	  System.out.println("Compra de Inventario: $" + compraInventario);
    	  System.out.println("Pago por Renta de Local: $" + pagoRentaLocal);
    	  System.out.println("Pago de Servicios Básicos: $" + pagoServiciosBasicos);
    	  System.out.println("Pago por Gastos de Compras: $" + pagoGastosCompras);
    	  System.out.println("Abono a Proveedores: $" + abonoProveedores);
    	  System.out.println("Subtotales: $" + subtotal1 + ", $" + subtotal2);
    	  System.out.println("Flujos de efectivo neto de actividades de operación: $" + flujoEfectivoOperacion);
    	  System.out.println("Saldo al Final del Ejercicio: $" + saldoFinalEjercicio);
    	  System.out.println("Más:");
    	  System.out.println("Saldo en Caja y Bancos: $" + saldoCajaBancos);
    	  System.out.println("Efectivo y equivalente de Efectivo: $" + efectivoEquivalente);
    	  System.out.println("Resultado de la Cuenta Caja: $" + resultadoCuentaCaja);
    	  System.out.println("Resultado de la Cuenta Bancos: $" + resultadoCuentaBancos);
    	  System.out.println("Total Comprobable: $" + totalComprobable);  
      }
}